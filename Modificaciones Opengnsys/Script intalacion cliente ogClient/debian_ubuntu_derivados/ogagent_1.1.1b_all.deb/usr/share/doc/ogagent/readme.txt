OGAgent is the agent intended for OpengGnsys interaction.

Please, visit https://opengnsys.es for more information
